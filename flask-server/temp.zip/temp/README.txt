The python files were wrote in python 3.10 and you may need to pip install the requests module in the windows command terminal.

pull.py : pulls data from sensors specified in "sensors.txt" from purpleair. For multiple sensors this
takes a while, so if clean.py is called before it finishes, some of the new data may be deleted or unsorted

clean.py : sorts data by timestamp and removes duplicates.
PMtoAQI.py : helper function used in clean.py 

data_updater : data_updater.exe is for automatically calling pull.py and clean.py every week. 
In order to make it run automatically, you can make a shortuct and put that shortcut in your 
startup folder by pressing the windows key + r and then typing shell:startup in the command prompt.

update_time : used by data_updater to store when the next time to pull data from purpleair is while the 
program is offline